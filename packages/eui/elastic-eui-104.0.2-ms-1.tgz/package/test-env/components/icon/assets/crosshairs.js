"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconCrosshairs = function EuiIconCrosshairs(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    d: "M5.822 1.874a.5.5 0 1 1 .335.942 5.517 5.517 0 0 0-3.34 3.341.5.5 0 1 1-.943-.335 6.517 6.517 0 0 1 3.948-3.948ZM1.864 10.15a.5.5 0 1 1 .944-.33 5.517 5.517 0 0 0 3.365 3.37.5.5 0 0 1-.333.943 6.517 6.517 0 0 1-3.976-3.983Zm8.302 3.981a.5.5 0 1 1-.333-.943 5.517 5.517 0 0 0 3.347-3.332.5.5 0 1 1 .941.337 6.517 6.517 0 0 1-3.955 3.938Zm3.968-8.285a.5.5 0 1 1-.943.331A5.517 5.517 0 0 0 9.85 2.82a.5.5 0 0 1 .337-.942 6.517 6.517 0 0 1 3.946 3.968ZM8.5 3.5a.5.5 0 0 1-1 0V.997a.5.5 0 0 1 1 0V3.5Zm-4.997 4a.5.5 0 0 1 0 1H1a.5.5 0 0 1 0-1h2.503ZM7.5 12.497a.5.5 0 0 1 1 0V15a.5.5 0 1 1-1 0v-2.503ZM12.497 8.5a.5.5 0 0 1 0-1H15a.5.5 0 1 1 0 1h-2.503ZM8 9a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"
  }));
};
var icon = exports.icon = EuiIconCrosshairs;