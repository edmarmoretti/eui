"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.icon = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var React = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
var _excluded = ["title", "titleId"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
// THIS IS A GENERATED FILE. DO NOT MODIFY MANUALLY. @see scripts/compile-icons.js
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiIconEql = function EuiIconEql(_ref) {
  var title = _ref.title,
    titleId = _ref.titleId,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  return (0, _react2.jsx)("svg", (0, _extends2.default)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    "aria-labelledby": titleId
  }, props), title ? (0, _react2.jsx)("title", {
    id: titleId
  }, title) : null, (0, _react2.jsx)("path", {
    d: "M15.862 14.18v.001a.482.482 0 0 1 .1.521.5.5 0 0 1-.447.299h-3.149c-.07 0-.136 0-.2-.003a.664.664 0 0 1-.414-.14c-.35-.31-.684-.637-1.001-.981l-1.772-1.738a5.941 5.941 0 0 1-3.802.14l-.045-.012a5.89 5.89 0 0 1-2.682-1.712A5.715 5.715 0 0 1 1.08 7.72a5.66 5.66 0 0 1 .348-3.118A5.78 5.78 0 0 1 3.39 2.124a5.979 5.979 0 0 1 6.136-.505 5.836 5.836 0 0 1 2.356 2.123 5.67 5.67 0 0 1 .873 3.017l.001.003c0 .128-.051.25-.143.34a.495.495 0 0 1-.694 0 .476.476 0 0 1-.143-.34c0-.95-.288-1.878-.826-2.668a4.88 4.88 0 0 0-2.198-1.769 4.99 4.99 0 0 0-2.83-.273 4.93 4.93 0 0 0-2.509 1.314 4.774 4.774 0 0 0-1.34 2.46A4.715 4.715 0 0 0 2.352 8.6a4.82 4.82 0 0 0 1.804 2.155c.805.528 1.752.81 2.721.81a4.899 4.899 0 0 0 1.296-.194l.032-.009.717-.211a.506.506 0 0 1 .483.111l1.11 1.026 1.788 1.752h2.03l-3.657-3.583a.475.475 0 0 1 .014-.666.495.495 0 0 1 .679-.013l4.493 4.402z"
  }), (0, _react2.jsx)("path", {
    d: "M7.097 3.468 9.679 4.93a.433.433 0 0 1 .218.37v2.924a.422.422 0 0 1-.218.37l-2.582 1.461a.438.438 0 0 1-.437 0L4.077 8.594a.433.433 0 0 1-.218-.37V5.3a.422.422 0 0 1 .218-.37L6.66 3.467a.446.446 0 0 1 .437 0zm1.845 4.27V5.784a.328.328 0 0 0-.17-.287L7.047 4.52a.342.342 0 0 0-.338 0l-1.726.977a.336.336 0 0 0-.168.287v1.953a.326.326 0 0 0 .17.287l1.724.977a.342.342 0 0 0 .338 0l1.726-.978a.334.334 0 0 0 .169-.287z"
  }));
};
var icon = exports.icon = EuiIconEql;