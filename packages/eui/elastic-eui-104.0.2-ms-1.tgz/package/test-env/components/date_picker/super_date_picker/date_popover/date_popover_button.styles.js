"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiDatePopoverButtonStyles = void 0;
var _react = require("@emotion/react");
var _super_date_picker = require("../super_date_picker.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "170kc3d-now",
  styles: "flex-grow:0.5!important;label:now;"
} : {
  name: "170kc3d-now",
  styles: "flex-grow:0.5!important;label:now;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiDatePopoverButtonStyles = exports.euiDatePopoverButtonStyles = function euiDatePopoverButtonStyles(euiThemeContext) {
  return {
    euiDatePopoverButton: /*#__PURE__*/(0, _react.css)((0, _super_date_picker._buttonStyles)(euiThemeContext), ";;label:euiDatePopoverButton;"),
    now: _ref
  };
};