"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useLoadingAriaLabel = void 0;
var _i18n = require("../i18n");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var useLoadingAriaLabel = exports.useLoadingAriaLabel = function useLoadingAriaLabel() {
  return (0, _i18n.useEuiI18n)('euiLoadingStrings.ariaLabel', 'Loading');
};