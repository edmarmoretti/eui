"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCommentEventStyles = exports.euiCommentEventHeaderStyles = exports.euiCommentEventBodyStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
var _high_contrast = require("../../global_styling/functions/high_contrast");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "yoyozp-euiCommentEvent",
  styles: "overflow:hidden;label:euiCommentEvent;"
} : {
  name: "yoyozp-euiCommentEvent",
  styles: "overflow:hidden;label:euiCommentEvent;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCommentEventStyles = exports.euiCommentEventStyles = function euiCommentEventStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiCommentEvent: _ref2,
    border: /*#__PURE__*/(0, _react.css)("border-width:", euiTheme.border.width.thin, ";border-style:solid;border-radius:", euiTheme.border.radius.medium, ";;label:border;")
  };
};
var _ref = process.env.NODE_ENV === "production" ? {
  name: "ui5tce-euiCommentEvent__headerEvent",
  styles: "align-items:center;display:inline-flex;white-space:pre-wrap;flex-wrap:wrap;label:euiCommentEvent__headerEvent;"
} : {
  name: "ui5tce-euiCommentEvent__headerEvent",
  styles: "align-items:center;display:inline-flex;white-space:pre-wrap;flex-wrap:wrap;label:euiCommentEvent__headerEvent;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCommentEventHeaderStyles = exports.euiCommentEventHeaderStyles = function euiCommentEventHeaderStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiCommentEvent__header: /*#__PURE__*/(0, _react.css)((0, _high_contrast.highContrastModeStyles)(euiThemeContext, {
      // Remove duplicate high contrast panel borders
      preferred: "\n          & > .euiPanel {\n            border: none;\n          }\n      "
    }), ";;label:euiCommentEvent__header;"),
    border: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('border-bottom-style', 'solid'), " ", (0, _global_styling.logicalCSS)('border-bottom-width', euiTheme.border.width.thin), ";;label:border;"),
    // Children
    euiCommentEvent__headerMain: /*#__PURE__*/(0, _react.css)("display:flex;flex:1;gap:", euiTheme.size.s, ";;label:euiCommentEvent__headerMain;"),
    euiCommentEvent__headerData: /*#__PURE__*/(0, _react.css)("display:flex;flex:1;align-items:center;flex-wrap:wrap;gap:", euiTheme.size.xs, ";;label:euiCommentEvent__headerData;"),
    euiCommentEvent__headerEventIcon: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('margin-right', euiTheme.size.xs), ";;label:euiCommentEvent__headerEventIcon;"),
    euiCommentEvent__headerUsername: /*#__PURE__*/(0, _react.css)("font-weight:", euiTheme.font.weight.semiBold, ";;label:euiCommentEvent__headerUsername;"),
    euiCommentEvent__headerEvent: _ref,
    euiCommentEvent__headerActions: /*#__PURE__*/(0, _react.css)("display:flex;flex-wrap:wrap;gap:", euiTheme.size.xs, ";;label:euiCommentEvent__headerActions;")
  };
};
var euiCommentEventBodyStyles = exports.euiCommentEventBodyStyles = function euiCommentEventBodyStyles(_ref3) {
  var euiTheme = _ref3.euiTheme;
  return {
    euiCommentEvent__body: /*#__PURE__*/(0, _react.css)(";label:euiCommentEvent__body;"),
    // types
    regular: /*#__PURE__*/(0, _react.css)("padding:", euiTheme.size.s, ";;label:regular;"),
    update: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('padding-top', euiTheme.size.xs), ";;label:update;"),
    custom: /*#__PURE__*/(0, _react.css)(";label:custom;")
  };
};