"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.components = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _utils = require("../../../../services/theme/utils");
var _manipulation = require("../../../../services/color/manipulation");
var _contrast = require("../../../../services/color/contrast");
var _buttons = require("./_buttons");
var _forms = require("./_forms");
var _colors_vis_light = require("./_colors_vis_light");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var component_colors = {
  badgeBackground: (0, _utils.computed)(function (_ref) {
    var _ref2 = (0, _slicedToArray2.default)(_ref, 1),
      lightShade = _ref2[0];
    return lightShade;
  }, ['colors.lightShade']),
  badgeBackgroundSubdued: (0, _utils.computed)(function (_ref3) {
    var _ref4 = (0, _slicedToArray2.default)(_ref3, 1),
      lightShade = _ref4[0];
    return (0, _manipulation.tint)(lightShade, 0.3);
  }, ['colors.lightShade']),
  badgeBorderColorHollow: (0, _utils.computed)(function (_ref5) {
    var _ref6 = (0, _slicedToArray2.default)(_ref5, 1),
      color = _ref6[0];
    return color;
  }, ['border.color']),
  badgeIconButtonBackgroundHover: (0, _utils.computed)(function (_ref7) {
    var _ref8 = (0, _slicedToArray2.default)(_ref7, 1),
      ghost = _ref8[0];
    return (0, _manipulation.transparentize)(ghost, 0.8);
  }, ['colors.ghost']),
  breadcrumbsApplicationBackground: (0, _utils.computed)(function (_ref9) {
    var _ref10 = (0, _slicedToArray2.default)(_ref9, 1),
      darkestShade = _ref10[0];
    return (0, _manipulation.tint)(darkestShade, 0.85);
  }, ['colors.darkestShade']),
  breadcrumbsApplicationColor: (0, _utils.computed)(function (_ref11) {
    var _ref12 = (0, _slicedToArray2.default)(_ref11, 1),
      darkestShade = _ref12[0];
    return (0, _manipulation.tint)(darkestShade, 0.2);
  }, ['colors.darkestShade']),
  buttonGroupBackgroundDisabledSelected: (0, _utils.computed)(function (_ref13) {
    var _ref14 = (0, _slicedToArray2.default)(_ref13, 1),
      disabled = _ref14[0];
    return disabled;
  }, ['colors.disabled']),
  buttonGroupBorderColor: (0, _utils.computed)(function (_ref15) {
    var _ref16 = (0, _slicedToArray2.default)(_ref15, 1),
      fullShade = _ref16[0];
    return (0, _manipulation.transparentize)(fullShade, 0.1);
  }, ['colors.fullShade']),
  buttonGroupBorderColorSelected: (0, _utils.computed)(function (_ref17) {
    var _ref18 = (0, _slicedToArray2.default)(_ref17, 1),
      emptyShade = _ref18[0];
    return (0, _manipulation.transparentize)(emptyShade, 0.2);
  }, ['colors.emptyShade']),
  buttonGroupFocusColor: (0, _utils.computed)(function (_ref19) {
    var _ref20 = (0, _slicedToArray2.default)(_ref19, 1),
      fullShade = _ref20[0];
    return fullShade;
  }, ['colors.fullShade']),
  bottomBarBackground: (0, _utils.computed)(function (_ref21) {
    var _ref22 = (0, _slicedToArray2.default)(_ref21, 1),
      lightestShade = _ref22[0];
    return (0, _manipulation.shade)(lightestShade, 0.5);
  }, ['colors.lightestShade']),
  codeBackground: (0, _utils.computed)(function (_ref23) {
    var _ref24 = (0, _slicedToArray2.default)(_ref23, 1),
      lightestShade = _ref24[0];
    return lightestShade;
  }, ['colors.lightestShade']),
  codeBackgroundSelected: 'inherit',
  codeColor: (0, _utils.computed)(function (_ref25) {
    var _ref26 = (0, _slicedToArray2.default)(_ref25, 2),
      lightestShade = _ref26[0],
      text = _ref26[1];
    return (0, _contrast.makeHighContrastColor)(text)(lightestShade);
  }, ['colors.lightestShade', 'colors.text']),
  codeInlineColor: (0, _utils.computed)(function (_ref27) {
    var _ref28 = (0, _slicedToArray2.default)(_ref27, 1),
      lightestShade = _ref28[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis3)(lightestShade);
  }, ['colors.lightestShade']),
  codeCommentColor: (0, _utils.computed)(function (_ref29) {
    var _ref30 = (0, _slicedToArray2.default)(_ref29, 2),
      lightestShade = _ref30[0],
      subduedText = _ref30[1];
    return (0, _contrast.makeHighContrastColor)(subduedText)(lightestShade);
  }, ['colors.lightestShade', 'colors.subduedText']),
  codeSelectorColor: 'inherit',
  codeStringColor: (0, _utils.computed)(function (_ref31) {
    var _ref32 = (0, _slicedToArray2.default)(_ref31, 1),
      lightestShade = _ref32[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis2)(lightestShade);
  }, ['colors.lightestShade']),
  codeTagColor: (0, _utils.computed)(function (_ref33) {
    var _ref34 = (0, _slicedToArray2.default)(_ref33, 1),
      lightestShade = _ref34[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis1)(lightestShade);
  }, ['colors.lightestShade']),
  codeNameColor: (0, _utils.computed)(function (_ref35) {
    var _ref36 = (0, _slicedToArray2.default)(_ref35, 1),
      lightestShade = _ref36[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis1)(lightestShade);
  }, ['colors.lightestShade']),
  codeNumberColor: (0, _utils.computed)(function (_ref37) {
    var _ref38 = (0, _slicedToArray2.default)(_ref37, 1),
      lightestShade = _ref38[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis0)(lightestShade);
  }, ['colors.lightestShade']),
  codeInlineCodeKeywordColor: (0, _utils.computed)(function (_ref39) {
    var _ref40 = (0, _slicedToArray2.default)(_ref39, 1),
      lightestShade = _ref40[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis6)(lightestShade);
  }, ['colors.lightestShade']),
  codeKeywordColor: (0, _utils.computed)(function (_ref41) {
    var _ref42 = (0, _slicedToArray2.default)(_ref41, 1),
      lightestShade = _ref42[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis3)(lightestShade);
  }, ['colors.lightestShade']),
  codeFunctionTitleColor: 'inherit',
  codeTypeColor: (0, _utils.computed)(function (_ref43) {
    var _ref44 = (0, _slicedToArray2.default)(_ref43, 1),
      lightestShade = _ref44[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis1)(lightestShade);
  }, ['colors.lightestShade']),
  codeAttributeColor: 'inherit',
  codeSymbolColor: (0, _utils.computed)(function (_ref45) {
    var _ref46 = (0, _slicedToArray2.default)(_ref45, 1),
      lightestShade = _ref46[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis9)(lightestShade);
  }, ['colors.lightestShade']),
  codeParamsColor: 'inherit',
  codeMetaColor: (0, _utils.computed)(function (_ref47) {
    var _ref48 = (0, _slicedToArray2.default)(_ref47, 2),
      lightestShade = _ref48[0],
      subduedText = _ref48[1];
    return (0, _contrast.makeHighContrastColor)(subduedText)(lightestShade);
  }, ['colors.lightestShade', 'colors.subduedText']),
  codeTitleColor: (0, _utils.computed)(function (_ref49) {
    var _ref50 = (0, _slicedToArray2.default)(_ref49, 1),
      lightestShade = _ref50[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis7)(lightestShade);
  }, ['colors.lightestShade']),
  codeSectionColor: (0, _utils.computed)(function (_ref51) {
    var _ref52 = (0, _slicedToArray2.default)(_ref51, 1),
      lightestShade = _ref52[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis9)(lightestShade);
  }, ['colors.lightestShade']),
  codeAdditionColor: (0, _utils.computed)(function (_ref53) {
    var _ref54 = (0, _slicedToArray2.default)(_ref53, 1),
      lightestShade = _ref54[0];
    return (0, _contrast.makeHighContrastColor)(_colors_vis_light.colorVisLight.euiColorVis0)(lightestShade);
  }, ['colors.lightestShade']),
  codeDeletionColor: (0, _utils.computed)(function (_ref55) {
    var _ref56 = (0, _slicedToArray2.default)(_ref55, 2),
      lightestShade = _ref56[0],
      danger = _ref56[1];
    return (0, _contrast.makeHighContrastColor)(danger)(lightestShade);
  }, ['colors.lightestShade', 'colors.danger']),
  codeSelectorClassColor: 'inherit',
  codeSelectorIdColor: 'inherit',
  collapsibleNavGroupBackground: (0, _utils.computed)(function (_ref57) {
    var _ref58 = (0, _slicedToArray2.default)(_ref57, 1),
      body = _ref58[0];
    return body;
  }, ['colors.body']),
  collapsibleNavGroupBackgroundDark: (0, _utils.computed)(function (_ref59) {
    var _ref60 = (0, _slicedToArray2.default)(_ref59, 1),
      darkestShade = _ref60[0];
    return (0, _manipulation.shade)(darkestShade, 0.2);
  }, ['colors.darkestShade']),
  dataGridBorderColor: (0, _utils.computed)(function (_ref61) {
    var _ref62 = (0, _slicedToArray2.default)(_ref61, 1),
      color = _ref62[0];
    return color;
  }, ['border.color']),
  dataGridVerticalLineBorderColor: (0, _utils.computed)(function (_ref63) {
    var _ref64 = (0, _slicedToArray2.default)(_ref63, 1),
      color = _ref64[0];
    return (0, _manipulation.tint)(color, 0.3);
  }, ['border.color']),
  dataGridRowBackground: (0, _utils.computed)(function (_ref65) {
    var _ref66 = (0, _slicedToArray2.default)(_ref65, 1),
      emptyShade = _ref66[0];
    return emptyShade;
  }, ['colors.emptyShade']),
  dataGridRowBackgroundHover: (0, _utils.computed)(function (_ref67) {
    var _ref68 = (0, _slicedToArray2.default)(_ref67, 1),
      highlight = _ref68[0];
    return highlight;
  }, ['colors.highlight']),
  dataGridRowBackgroundSelect: (0, _utils.computed)(function (_ref69) {
    var _ref70 = (0, _slicedToArray2.default)(_ref69, 1),
      highlight = _ref70[0];
    return highlight;
  }, ['colors.highlight']),
  dataGridRowBackgroundSelectHover: (0, _utils.computed)(function (_ref71) {
    var _ref72 = (0, _slicedToArray2.default)(_ref71, 1),
      highlight = _ref72[0];
    return highlight;
  }, ['colors.highlight']),
  dataGridRowStripesBackground: (0, _utils.computed)(function (_ref73) {
    var _ref74 = (0, _slicedToArray2.default)(_ref73, 1),
      emptyShade = _ref74[0];
    return emptyShade;
  }, ['colors.emptyShade']),
  dataGridRowStripesBackgroundHover: (0, _utils.computed)(function (_ref75) {
    var _ref76 = (0, _slicedToArray2.default)(_ref75, 1),
      highlight = _ref76[0];
    return highlight;
  }, ['colors.highlight']),
  dataGridRowStripesBackgroundStriped: (0, _utils.computed)(function (_ref77) {
    var _ref78 = (0, _slicedToArray2.default)(_ref77, 1),
      lightestShade = _ref78[0];
    return lightestShade;
  }, ['colors.lightestShade']),
  dataGridRowStripesBackgroundStripedHover: (0, _utils.computed)(function (_ref79) {
    var _ref80 = (0, _slicedToArray2.default)(_ref79, 1),
      highlight = _ref80[0];
    return highlight;
  }, ['colors.highlight']),
  dataGridRowStripesBackgroundSelect: (0, _utils.computed)(function (_ref81) {
    var _ref82 = (0, _slicedToArray2.default)(_ref81, 1),
      highlight = _ref82[0];
    return highlight;
  }, ['colors.highlight']),
  dataGridRowStripesBackgroundSelectHover: (0, _utils.computed)(function (_ref83) {
    var _ref84 = (0, _slicedToArray2.default)(_ref83, 1),
      highlight = _ref84[0];
    return highlight;
  }, ['colors.highlight']),
  dragDropDraggingBackground: (0, _utils.computed)(function (_ref85) {
    var _ref86 = (0, _slicedToArray2.default)(_ref85, 1),
      success = _ref86[0];
    return (0, _manipulation.transparentize)(success, 0.1);
  }, ['colors.success']),
  dragDropDraggingOverBackground: (0, _utils.computed)(function (_ref87) {
    var _ref88 = (0, _slicedToArray2.default)(_ref87, 1),
      success = _ref88[0];
    return (0, _manipulation.transparentize)(success, 0.25);
  }, ['colors.success']),
  filterButtonBadgeBackgroundHover: (0, _utils.computed)(function (_ref89) {
    var _ref90 = (0, _slicedToArray2.default)(_ref89, 1),
      lightShade = _ref90[0];
    return (0, _manipulation.tint)(lightShade, 0.3);
  }, ['colors.lightShade']),
  filterSelectItemBackgroundFocusDisabled: (0, _utils.computed)(function (_ref91) {
    var _ref92 = (0, _slicedToArray2.default)(_ref91, 1),
      disabled = _ref92[0];
    return (0, _manipulation.transparentize)(disabled, 0.1);
  }, ['colors.disabled']),
  flyoutFooterBackground: (0, _utils.computed)(function (_ref93) {
    var _ref94 = (0, _slicedToArray2.default)(_ref93, 1),
      lightestShade = _ref94[0];
    return lightestShade;
  }, ['colors.lightestShade']),
  flyoutCloseButtonInsideBackground: (0, _utils.computed)(function (_ref95) {
    var _ref96 = (0, _slicedToArray2.default)(_ref95, 1),
      emptyShade = _ref96[0];
    return (0, _manipulation.transparentize)(emptyShade, 0.9);
  }, ['colors.emptyShade']),
  headerBackground: (0, _utils.computed)(function (_ref97) {
    var _ref98 = (0, _slicedToArray2.default)(_ref97, 1),
      emptyShade = _ref98[0];
    return emptyShade;
  }, ['colors.emptyShade']),
  headerDarkBackground: (0, _utils.computed)(function (_ref99) {
    var _ref100 = (0, _slicedToArray2.default)(_ref99, 1),
      darkestShade = _ref100[0];
    return (0, _manipulation.shade)(darkestShade, 0.28);
  }, ['colors.darkestShade']),
  headerDarkSearchBorderColor: (0, _utils.computed)(function (_ref101) {
    var _ref102 = (0, _slicedToArray2.default)(_ref101, 1),
      ghost = _ref102[0];
    return (0, _manipulation.transparentize)(ghost, 0.3);
  }, ['colors.ghost']),
  headerDarkSectionItemBackgroundFocus: (0, _utils.computed)(function (_ref103) {
    var _ref104 = (0, _slicedToArray2.default)(_ref103, 1),
      primary = _ref104[0];
    return (0, _manipulation.shade)(primary, 0.5);
  }, ['colors.primary']),
  keyPadMenuItemBackgroundDisabledSelect: (0, _utils.computed)(function (_ref105) {
    var _ref106 = (0, _slicedToArray2.default)(_ref105, 1),
      disabled = _ref106[0];
    return (0, _manipulation.transparentize)(disabled, 0.1);
  }, ['colors.disabled']),
  listGroupItemBackgroundPrimaryActive: (0, _utils.computed)(function (_ref107) {
    var _ref108 = (0, _slicedToArray2.default)(_ref107, 1),
      lightShade = _ref108[0];
    return (0, _manipulation.transparentize)(lightShade, 0.2);
  }, ['colors.lightShade']),
  listGroupItemBackgroundSubduedActive: (0, _utils.computed)(function (_ref109) {
    var _ref110 = (0, _slicedToArray2.default)(_ref109, 1),
      primary = _ref110[0];
    return (0, _manipulation.transparentize)(primary, 0.1);
  }, ['colors.primary']),
  listGroupItemBackgroundHover: (0, _utils.computed)(function (_ref111) {
    var _ref112 = (0, _slicedToArray2.default)(_ref111, 1),
      lightShade = _ref112[0];
    return (0, _manipulation.transparentize)(lightShade, 0.2);
  }, ['colors.lightShade']),
  listGroupItemBackgroundPrimaryHover: (0, _utils.computed)(function (_ref113) {
    var _ref114 = (0, _slicedToArray2.default)(_ref113, 1),
      primary = _ref114[0];
    return (0, _manipulation.transparentize)(primary, 0.1);
  }, ['colors.primary']),
  loadingSpinnerBorder: (0, _utils.computed)(function (_ref115) {
    var _ref116 = (0, _slicedToArray2.default)(_ref115, 1),
      lightShade = _ref116[0];
    return lightShade;
  }, ['colors.lightShade']),
  loadingSpinnerHighlight: (0, _utils.computed)(function (_ref117) {
    var _ref118 = (0, _slicedToArray2.default)(_ref117, 1),
      primary = _ref118[0];
    return primary;
  }, ['colors.primary']),
  loadingChartMonoBackground0: (0, _utils.computed)(function (_ref119) {
    var _ref120 = (0, _slicedToArray2.default)(_ref119, 1),
      lightShade = _ref120[0];
    return lightShade;
  }, ['colors.lightShade']),
  loadingChartMonoBackground1: (0, _utils.computed)(function (_ref121) {
    var _ref122 = (0, _slicedToArray2.default)(_ref121, 1),
      lightShade = _ref122[0];
    return (0, _manipulation.shade)(lightShade, 0.04);
  }, ['colors.lightShade']),
  loadingChartMonoBackground2: (0, _utils.computed)(function (_ref123) {
    var _ref124 = (0, _slicedToArray2.default)(_ref123, 1),
      lightShade = _ref124[0];
    return (0, _manipulation.shade)(lightShade, 0.08);
  }, ['colors.lightShade']),
  loadingChartMonoBackground3: (0, _utils.computed)(function (_ref125) {
    var _ref126 = (0, _slicedToArray2.default)(_ref125, 1),
      lightShade = _ref126[0];
    return (0, _manipulation.shade)(lightShade, 0.12);
  }, ['colors.lightShade']),
  markBackground: (0, _utils.computed)(function (_ref127) {
    var _ref128 = (0, _slicedToArray2.default)(_ref127, 1),
      primary = _ref128[0];
    return (0, _manipulation.transparentize)(primary, 0.1);
  }, ['colors.primary']),
  markdownFormatTableBorderColor: (0, _utils.computed)(function (_ref129) {
    var _ref130 = (0, _slicedToArray2.default)(_ref129, 1),
      fullShade = _ref130[0];
    return (0, _manipulation.transparentize)(fullShade, 0.15);
  }, ['colors.fullShade']),
  overlayMaskBackground: (0, _utils.computed)(function (_ref131) {
    var _ref132 = (0, _slicedToArray2.default)(_ref131, 1),
      backgroundBaseInteractiveOverlay = _ref132[0];
    return backgroundBaseInteractiveOverlay;
  }, ['colors.backgroundBaseInteractiveOverlay']),
  overlayMaskBackgroundHighContrast: (0, _utils.computed)(function (_ref133) {
    var _ref134 = (0, _slicedToArray2.default)(_ref133, 1),
      ink = _ref134[0];
    return (0, _manipulation.transparentize)(ink, 0.85);
  }, ['colors.ink']),
  popoverPanelBackground: (0, _utils.computed)(function (_ref135) {
    var _ref136 = (0, _slicedToArray2.default)(_ref135, 1),
      emptyShade = _ref136[0];
    return emptyShade;
  }, ['colors.emptyShade']),
  popoverFooterBorderColor: (0, _utils.computed)(function (_ref137) {
    var _ref138 = (0, _slicedToArray2.default)(_ref137, 1),
      color = _ref138[0];
    return color;
  }, ['border.color']),
  scrollbarTrackColor: (0, _utils.computed)(function (_ref139) {
    var _ref140 = (0, _slicedToArray2.default)(_ref139, 1),
      body = _ref140[0];
    return (0, _manipulation.shade)(body, 0.03);
  }, ['colors.body']),
  sideNavItemEmphasizedBackground: (0, _utils.computed)(function (_ref141) {
    var _ref142 = (0, _slicedToArray2.default)(_ref141, 1),
      lightShade = _ref142[0];
    return (0, _manipulation.transparentize)(lightShade, 0.3);
  }, ['colors.lightShade']),
  selectableListItemBorderColor: (0, _utils.computed)(function (_ref143) {
    var _ref144 = (0, _slicedToArray2.default)(_ref143, 1),
      color = _ref144[0];
    return (0, _manipulation.transparentize)(color, 0.4);
  }, ['border.color']),
  skeletonBackgroundSkeletonMiddleHighContrast: (0, _utils.computed)(function (_ref145) {
    var _ref146 = (0, _slicedToArray2.default)(_ref145, 1),
      emptyShade = _ref146[0];
    return emptyShade;
  }, ['colors.emptyShade']),
  superDatePickerBackgroundSuccees: (0, _utils.computed)(function (_ref147) {
    var _ref148 = (0, _slicedToArray2.default)(_ref147, 1),
      success = _ref148[0];
    return (0, _manipulation.tint)(success, 0.9);
  }, ['colors.success']),
  switchBackgroundOn: (0, _utils.computed)(function (_ref149) {
    var _ref150 = (0, _slicedToArray2.default)(_ref149, 1),
      primary = _ref150[0];
    return primary;
  }, ['colors.primary']),
  switchBackgroundOff: (0, _utils.computed)(function (_ref151) {
    var _ref152 = (0, _slicedToArray2.default)(_ref151, 1),
      lightestShade = _ref152[0];
    return (0, _manipulation.shade)(lightestShade, 0.4);
  }, ['colors.lightestShade']),
  switchUncompressedBackgroundDisabled: (0, _utils.computed)(function (_ref153) {
    var _ref154 = (0, _slicedToArray2.default)(_ref153, 1),
      lightShade = _ref154[0];
    return (0, _manipulation.tint)(lightShade, 0.5);
  }, ['colors.lightShade']),
  switchCompressedBackgroundDisabled: (0, _utils.computed)(function (_ref155) {
    var _ref156 = (0, _slicedToArray2.default)(_ref155, 1),
      lightShade = _ref156[0];
    return (0, _manipulation.tint)(lightShade, 0.25);
  }, ['colors.lightShade']),
  switchMiniBackgroundDisabled: (0, _utils.computed)(function (_ref157) {
    var _ref158 = (0, _slicedToArray2.default)(_ref157, 1),
      lightShade = _ref158[0];
    return (0, _manipulation.tint)(lightShade, 0);
  }, ['colors.lightShade']),
  switchThumbBackgroundDisabled: 'transparent',
  switchThumbBorderOn: (0, _utils.computed)(function (_ref159) {
    var _ref160 = (0, _slicedToArray2.default)(_ref159, 1),
      lightestShade = _ref160[0];
    return (0, _manipulation.shade)(lightestShade, 0.4);
  }, ['colors.lightestShade']),
  switchThumbBorderOff: (0, _utils.computed)(function (_ref161) {
    var _ref162 = (0, _slicedToArray2.default)(_ref161, 1),
      lightestShade = _ref162[0];
    return (0, _manipulation.shade)(lightestShade, 0.4);
  }, ['colors.lightestShade']),
  switchIconDisabled: (0, _utils.computed)(function (_ref163) {
    var _ref164 = (0, _slicedToArray2.default)(_ref163, 1),
      lightestShade = _ref164[0];
    return (0, _manipulation.shade)(lightestShade, 0.4);
  }, ['colors.lightestShade']),
  tableRowBackgroundHover: (0, _utils.computed)(function (_ref165) {
    var _ref166 = (0, _slicedToArray2.default)(_ref165, 1),
      lightestShade = _ref166[0];
    return (0, _manipulation.tint)(lightestShade, 0.5);
  }, ['colors.lightestShade']),
  tableRowBackgroundSelected: (0, _utils.computed)(function (_ref167) {
    var _ref168 = (0, _slicedToArray2.default)(_ref167, 1),
      primary = _ref168[0];
    return (0, _manipulation.tint)(primary, 0.96);
  }, ['colors.primary']),
  tableRowBackgroundSelectedHover: (0, _utils.computed)(function (_ref169) {
    var _ref170 = (0, _slicedToArray2.default)(_ref169, 1),
      primary = _ref170[0];
    return (0, _manipulation.tint)(primary, 0.9);
  }, ['colors.primary']),
  tableRowInteractiveBackgroundHover: (0, _utils.computed)(function (_ref171) {
    var _ref172 = (0, _slicedToArray2.default)(_ref171, 1),
      primary = _ref172[0];
    return (0, _manipulation.transparentize)(primary, 0.05);
  }, ['colors.primary']),
  tableRowInteractiveBackgroundFocus: (0, _utils.computed)(function (_ref173) {
    var _ref174 = (0, _slicedToArray2.default)(_ref173, 1),
      primary = _ref174[0];
    return (0, _manipulation.transparentize)(primary, 0.1);
  }, ['colors.primary']),
  tableCellSortableIconColor: (0, _utils.computed)(function (_ref175) {
    var _ref176 = (0, _slicedToArray2.default)(_ref175, 2),
      emptyShade = _ref176[0],
      subduedText = _ref176[1];
    var color = (0, _manipulation.tint)(subduedText, 0.9);
    return (0, _contrast.makeHighContrastColor)(
    // Tint it arbitrarily high, the contrast util will take care of lowering back down to WCAG
    color, 3 // 3:1 ratio from https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html
    )(emptyShade);
  }, ['colors.emptyShade', 'colors.subduedText']),
  tooltipBackground: (0, _utils.computed)(function (_ref177) {
    var _ref178 = (0, _slicedToArray2.default)(_ref177, 1),
      fullShade = _ref178[0];
    return (0, _manipulation.tint)(fullShade, 0.25);
  }, ['colors.fullShade']),
  tooltipBorder: (0, _utils.computed)(function (_ref179) {
    var _ref180 = (0, _slicedToArray2.default)(_ref179, 1),
      fullShade = _ref180[0];
    return (0, _manipulation.tint)(fullShade, 0.35);
  }, ['colors.fullShade']),
  tooltipBorderFloating: (0, _utils.computed)(function (_ref181) {
    var _ref182 = (0, _slicedToArray2.default)(_ref181, 1),
      borderBaseFloating = _ref182[0];
    return borderBaseFloating;
  }, ['colors.borderBaseFloating']),
  tourFooterBackground: (0, _utils.computed)(function (_ref183) {
    var _ref184 = (0, _slicedToArray2.default)(_ref183, 1),
      lightestShade = _ref184[0];
    return (0, _manipulation.tint)(lightestShade, 0.5);
  }, ['colors.lightestShade']),
  treeViewItemBackgroundHover: (0, _utils.computed)(function (_ref185) {
    var _ref186 = (0, _slicedToArray2.default)(_ref185, 1),
      text = _ref186[0];
    return (0, _manipulation.transparentize)(text, 0.1);
  }, ['colors.text'])
};
var components = exports.components = {
  buttons: _buttons.buttons,
  forms: _forms.forms,
  LIGHT: component_colors,
  DARK: _objectSpread(_objectSpread({}, component_colors), {}, {
    badgeBorderColorHollow: (0, _utils.computed)(function (_ref187) {
      var _ref188 = (0, _slicedToArray2.default)(_ref187, 1),
        color = _ref188[0];
      return (0, _manipulation.tint)(color, 0.15);
    }, ['border.color']),
    breadcrumbsApplicationBackground: (0, _utils.computed)(function (_ref189) {
      var _ref190 = (0, _slicedToArray2.default)(_ref189, 1),
        darkestShade = _ref190[0];
      return (0, _manipulation.shade)(darkestShade, 0.7);
    }, ['colors.darkestShade']),
    breadcrumbsApplicationColor: (0, _utils.computed)(function (_ref191) {
      var _ref192 = (0, _slicedToArray2.default)(_ref191, 1),
        darkestShade = _ref192[0];
      return (0, _manipulation.shade)(darkestShade, 0.2);
    }, ['colors.darkestShade']),
    collapsibleNavGroupBackground: (0, _utils.computed)(function (_ref193) {
      var _ref194 = (0, _slicedToArray2.default)(_ref193, 1),
        lightestShade = _ref194[0];
      return (0, _manipulation.shade)(lightestShade, 0.5);
    }, ['colors.lightestShade']),
    collapsibleNavGroupBackgroundDark: (0, _utils.computed)(function (_ref195) {
      var _ref196 = (0, _slicedToArray2.default)(_ref195, 1),
        lightestShade = _ref196[0];
      return (0, _manipulation.shade)(lightestShade, 0.5);
    }, ['colors.lightestShade']),
    dataGridVerticalLineBorderColor: (0, _utils.computed)(function (_ref197) {
      var _ref198 = (0, _slicedToArray2.default)(_ref197, 1),
        color = _ref198[0];
      return (0, _manipulation.shade)(color, 0.3);
    }, ['border.color']),
    headerDarkBackground: (0, _utils.computed)(function (_ref199) {
      var _ref200 = (0, _slicedToArray2.default)(_ref199, 1),
        lightestShade = _ref200[0];
      return (0, _manipulation.shade)(lightestShade, 0.5);
    }, ['colors.lightestShade']),
    keyPadMenuItemBackgroundDisabledSelect: (0, _utils.computed)(function (_ref201) {
      var _ref202 = (0, _slicedToArray2.default)(_ref201, 1),
        disabled = _ref202[0];
      return (0, _manipulation.transparentize)(disabled, 0.2);
    }, ['colors.disabled']),
    listGroupItemBackgroundSubduedActive: (0, _utils.computed)(function (_ref203) {
      var _ref204 = (0, _slicedToArray2.default)(_ref203, 1),
        lightShade = _ref204[0];
      return (0, _manipulation.transparentize)(lightShade, 0.4);
    }, ['colors.lightShade']),
    loadingChartMonoBackground0: (0, _utils.computed)(function (_ref205) {
      var _ref206 = (0, _slicedToArray2.default)(_ref205, 1),
        lightShade = _ref206[0];
      return lightShade;
    }, ['colors.lightShade']),
    loadingChartMonoBackground1: (0, _utils.computed)(function (_ref207) {
      var _ref208 = (0, _slicedToArray2.default)(_ref207, 1),
        lightShade = _ref208[0];
      return (0, _manipulation.tint)(lightShade, 0.04);
    }, ['colors.lightShade']),
    loadingChartMonoBackground2: (0, _utils.computed)(function (_ref209) {
      var _ref210 = (0, _slicedToArray2.default)(_ref209, 1),
        lightShade = _ref210[0];
      return (0, _manipulation.tint)(lightShade, 0.08);
    }, ['colors.lightShade']),
    loadingChartMonoBackground3: (0, _utils.computed)(function (_ref211) {
      var _ref212 = (0, _slicedToArray2.default)(_ref211, 1),
        lightShade = _ref212[0];
      return (0, _manipulation.tint)(lightShade, 0.12);
    }, ['colors.lightShade']),
    markBackground: (0, _utils.computed)(function (_ref213) {
      var _ref214 = (0, _slicedToArray2.default)(_ref213, 1),
        primary = _ref214[0];
      return (0, _manipulation.transparentize)(primary, 0.3);
    }, ['colors.primary']),
    popoverPanelBackground: (0, _utils.computed)(function (_ref215) {
      var _ref216 = (0, _slicedToArray2.default)(_ref215, 1),
        emptyShade = _ref216[0];
      return (0, _manipulation.tint)(emptyShade, 0.025);
    }, ['colors.emptyShade']),
    scrollbarTrackColor: (0, _utils.computed)(function (_ref217) {
      var _ref218 = (0, _slicedToArray2.default)(_ref217, 1),
        body = _ref218[0];
      return (0, _manipulation.tint)(body, 0.07);
    }, ['colors.body']),
    skeletonBackgroundSkeletonMiddleHighContrast: (0, _utils.computed)(function (_ref219) {
      var _ref220 = (0, _slicedToArray2.default)(_ref219, 1),
        lightShade = _ref220[0];
      return (0, _manipulation.tint)(lightShade, 0.12);
    }, ['colors.lightShade']),
    superDatePickerBackgroundSuccees: (0, _utils.computed)(function (_ref221) {
      var _ref222 = (0, _slicedToArray2.default)(_ref221, 1),
        success = _ref222[0];
      return (0, _manipulation.shade)(success, 0.7);
    }, ['colors.success']),
    switchBackgroundOff: (0, _utils.computed)(function (_ref223) {
      var _ref224 = (0, _slicedToArray2.default)(_ref223, 1),
        lightestShade = _ref224[0];
      return (0, _manipulation.tint)(lightestShade, 0.31);
    }, ['colors.lightestShade']),
    switchUncompressedBackgroundDisabled: (0, _utils.computed)(function (_ref225) {
      var _ref226 = (0, _slicedToArray2.default)(_ref225, 1),
        lightShade = _ref226[0];
      return lightShade;
    }, ['colors.lightShade']),
    switchCompressedBackgroundDisabled: (0, _utils.computed)(function (_ref227) {
      var _ref228 = (0, _slicedToArray2.default)(_ref227, 1),
        lightShade = _ref228[0];
      return lightShade;
    }, ['colors.lightShade']),
    switchMiniBackgroundDisabled: (0, _utils.computed)(function (_ref229) {
      var _ref230 = (0, _slicedToArray2.default)(_ref229, 1),
        lightShade = _ref230[0];
      return lightShade;
    }, ['colors.lightShade']),
    switchThumbBorderOn: (0, _utils.computed)(function (_ref231) {
      var _ref232 = (0, _slicedToArray2.default)(_ref231, 1),
        lightestShade = _ref232[0];
      return (0, _manipulation.tint)(lightestShade, 0.31);
    }, ['colors.lightestShade']),
    switchThumbBorderOff: (0, _utils.computed)(function (_ref233) {
      var _ref234 = (0, _slicedToArray2.default)(_ref233, 1),
        lightestShade = _ref234[0];
      return (0, _manipulation.tint)(lightestShade, 0.31);
    }, ['colors.lightestShade']),
    switchIconDisabled: (0, _utils.computed)(function (_ref235) {
      var _ref236 = (0, _slicedToArray2.default)(_ref235, 1),
        lightestShade = _ref236[0];
      return (0, _manipulation.tint)(lightestShade, 0.31);
    }, ['colors.lightestShade']),
    tableRowBackgroundHover: (0, _utils.computed)(function (_ref237) {
      var _ref238 = (0, _slicedToArray2.default)(_ref237, 1),
        lightestShade = _ref238[0];
      return lightestShade;
    }, ['colors.lightestShade']),
    tableRowBackgroundSelected: (0, _utils.computed)(function (_ref239) {
      var _ref240 = (0, _slicedToArray2.default)(_ref239, 1),
        primary = _ref240[0];
      return (0, _manipulation.shade)(primary, 0.7);
    }, ['colors.primary']),
    tableRowBackgroundSelectedHover: (0, _utils.computed)(function (_ref241) {
      var _ref242 = (0, _slicedToArray2.default)(_ref241, 1),
        primary = _ref242[0];
      return (0, _manipulation.shade)(primary, 0.75);
    }, ['colors.primary']),
    tableCellSortableIconColor: (0, _utils.computed)(function (_ref243) {
      var _ref244 = (0, _slicedToArray2.default)(_ref243, 2),
        emptyShade = _ref244[0],
        subduedText = _ref244[1];
      var color = (0, _manipulation.shade)(subduedText, 0.9);
      return (0, _contrast.makeHighContrastColor)(color, 3)(emptyShade);
    }, ['colors.emptyShade', 'colors.subduedText']),
    tooltipBackground: (0, _utils.computed)(function (_ref245) {
      var _ref246 = (0, _slicedToArray2.default)(_ref245, 1),
        emptyShade = _ref246[0];
      return (0, _manipulation.shade)(emptyShade, 1);
    }, ['colors.emptyShade']),
    tooltipBorder: (0, _utils.computed)(function (_ref247) {
      var _ref248 = (0, _slicedToArray2.default)(_ref247, 1),
        fullShade = _ref248[0];
      return (0, _manipulation.shade)(fullShade, 0.8);
    }, ['colors.fullShade']),
    tourFooterBackground: (0, _utils.computed)(function (_ref249) {
      var _ref250 = (0, _slicedToArray2.default)(_ref249, 1),
        lightestShade = _ref250[0];
      return (0, _manipulation.shade)(lightestShade, 0.45);
    }, ['colors.lightestShade']),
    treeViewItemBackgroundHover: (0, _utils.computed)(function (_ref251) {
      var _ref252 = (0, _slicedToArray2.default)(_ref251, 1),
        text = _ref252[0];
      return (0, _manipulation.transparentize)(text, 0.2);
    }, ['colors.text'])
  })
};