"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.colorVisDark = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _manipulation = require("../../../../services/color/manipulation");
var _colors_vis_light = require("./_colors_vis_light");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var colorVisDark = exports.colorVisDark = _objectSpread(_objectSpread({}, _colors_vis_light.colorVisLight), {}, {
  euiColorVisText0: '#7DE2D1',
  euiColorVisText1: '#1BA9F5',
  euiColorVisText2: '#F990C0',
  euiColorVisText3: (0, _manipulation.tint)(_colors_vis_light.colorVisLight.euiColorVisBehindText3, 0.2).toUpperCase(),
  // '#BA9FDA',
  euiColorVisText4: (0, _manipulation.tint)(_colors_vis_light.colorVisLight.euiColorVisBehindText4, 0.2).toUpperCase(),
  // '#E9B8D2',
  euiColorVisText5: (0, _manipulation.tint)(_colors_vis_light.colorVisLight.euiColorVisBehindText5, 0.2).toUpperCase(),
  // '#F4E08C',
  euiColorVisText6: (0, _manipulation.tint)(_colors_vis_light.colorVisLight.euiColorVisBehindText6, 0.2).toUpperCase(),
  // '#DBCDB3',
  euiColorVisText7: '#FFCE7A',
  euiColorVisText8: (0, _manipulation.tint)(_colors_vis_light.colorVisLight.euiColorVisBehindText8, 0.2).toUpperCase(),
  // '#D09689',
  euiColorVisText9: '#F66'
});