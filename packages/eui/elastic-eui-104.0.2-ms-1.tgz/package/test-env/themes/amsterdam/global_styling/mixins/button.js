"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "BUTTON_COLORS", {
  enumerable: true,
  get: function get() {
    return _button.BUTTON_COLORS;
  }
});
Object.defineProperty(exports, "BUTTON_DISPLAYS", {
  enumerable: true,
  get: function get() {
    return _button.BUTTON_DISPLAYS;
  }
});
Object.defineProperty(exports, "euiButtonColor", {
  enumerable: true,
  get: function get() {
    return _button.euiButtonColor;
  }
});
Object.defineProperty(exports, "euiButtonEmptyColor", {
  enumerable: true,
  get: function get() {
    return _button.euiButtonEmptyColor;
  }
});
Object.defineProperty(exports, "euiButtonFillColor", {
  enumerable: true,
  get: function get() {
    return _button.euiButtonFillColor;
  }
});
Object.defineProperty(exports, "euiButtonSizeMap", {
  enumerable: true,
  get: function get() {
    return _button.euiButtonSizeMap;
  }
});
Object.defineProperty(exports, "useEuiButtonColorCSS", {
  enumerable: true,
  get: function get() {
    return _button.useEuiButtonColorCSS;
  }
});
Object.defineProperty(exports, "useEuiButtonFocusCSS", {
  enumerable: true,
  get: function get() {
    return _button.useEuiButtonFocusCSS;
  }
});
var _button = require("../../../../global_styling/mixins/_button");