"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useEuiBorderColorCSS = exports.useEuiBackgroundColorCSS = exports.useEuiBackgroundColor = exports.euiBorderColor = exports.euiBackgroundColor = exports.BACKGROUND_COLORS = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _react = require("@emotion/react");
var _euiThemeCommon = require("@elastic/eui-theme-common");
var _services = require("../../services");
var _button = require("./_button");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var BACKGROUND_COLORS = exports.BACKGROUND_COLORS = ['transparent', 'plain', 'subdued', 'highlighted', 'accent', 'accentSecondary', 'primary', 'success', 'warning', 'danger'].concat((0, _toConsumableArray2.default)(_button.SEVERITY_COLORS));
/**
 * @deprecated - use background tokens directly
 * @returns A single background color with optional alpha transparency
 */
var euiBackgroundColor = exports.euiBackgroundColor = function euiBackgroundColor(_ref, color) {
  var euiTheme = _ref.euiTheme;
  var _ref2 = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
    method = _ref2.method;
  if (color === 'transparent') return 'transparent';
  if (method === 'transparent') {
    var tokenName = (0, _euiThemeCommon.getTokenName)('backgroundTransparent', color);
    return euiTheme.colors[tokenName];
  } else {
    var _tokenName = (0, _euiThemeCommon.getTokenName)('backgroundBase', color);
    return euiTheme.colors[_tokenName];
  }
};

/**
 * @deprecated
 * @returns An object map of color keys to color values, categorized by
 * opaque (default) vs transparency (hover/focus states) methods.
 * e.g. {
 *  opaque: { danger: '#000', success: '#fff', ... },
 *  transparent: { danger: 'rgba(0,0,0,0.1)', success: 'rgba(255,255,255,0.1)', ... },
 * }
 */
var _euiBackgroundColorMap = function _euiBackgroundColorMap(euiThemeContext) {
  return {
    opaque: BACKGROUND_COLORS.reduce(function (acc, color) {
      return _objectSpread(_objectSpread({}, acc), {}, (0, _defineProperty2.default)({}, color, euiBackgroundColor(euiThemeContext, color)));
    }, {}),
    transparent: BACKGROUND_COLORS.reduce(function (acc, color) {
      return _objectSpread(_objectSpread({}, acc), {}, (0, _defineProperty2.default)({}, color, euiBackgroundColor(euiThemeContext, color, {
        method: 'transparent'
      })));
    }, {})
  };
};

/**
 * @deprecated
 */
var useEuiBackgroundColor = exports.useEuiBackgroundColor = function useEuiBackgroundColor(color) {
  var _ref3 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    method = _ref3.method;
  var backgroundColorMap = (0, _services.useEuiMemoizedStyles)(_euiBackgroundColorMap);
  return backgroundColorMap[method || 'opaque'][color];
};

/**
 * @returns An object map of color keys to CSS,
 * e.g. { danger: css``, success: css``, ... }
 */
var _euiBackgroundColors = function _euiBackgroundColors(euiThemeContext) {
  return BACKGROUND_COLORS.reduce(function (acc, color) {
    var tokenName = (0, _euiThemeCommon.getTokenName)('backgroundBase', color);
    var backgroundColor = color === 'transparent' ? 'transparent' : euiThemeContext.euiTheme.colors[tokenName];
    return _objectSpread(_objectSpread({}, acc), {}, (0, _defineProperty2.default)({}, color, /*#__PURE__*/(0, _react.css)("background-color:", backgroundColor, ";label:", color, ";")));
  }, {});
};

/**
 * Hook to retrieve background style for a background color variant
 * @returns An object map of color keys to CSS,
 * e.g. { danger: css``, success: css``, ... }
 */
var useEuiBackgroundColorCSS = exports.useEuiBackgroundColorCSS = function useEuiBackgroundColorCSS() {
  return (0, _services.useEuiMemoizedStyles)(_euiBackgroundColors);
};

/**
 * Border colors
 * @deprecated - use border tokens directly or use
 * `useEuiBorderColorCSS()` for composed styles
 */

var euiBorderColor = exports.euiBorderColor = function euiBorderColor(_ref4, color) {
  var euiTheme = _ref4.euiTheme;
  switch (color) {
    case 'transparent':
      return euiTheme.border.color;
    default:
      {
        // border tokens are overridden in for high contrast mode
        // in high_contrast_overrides.ts
        var tokenName = (0, _euiThemeCommon.getTokenName)('borderBase', color);
        return euiTheme.colors[tokenName];
      }
  }
};

/**
 * @returns An object map of color keys to CSS,
 * e.g. { danger: css``, success: css``, ... }
 */
var _euiBorderColors = function _euiBorderColors(euiThemeContext) {
  return BACKGROUND_COLORS.reduce(function (acc, color) {
    // border tokens are overridden in for high contrast mode
    // in high_contrast_overrides.ts
    var borderToken = (0, _euiThemeCommon.getTokenName)('borderBase', color);
    var borderColor = color === 'transparent' ? euiThemeContext.euiTheme.border.color : euiThemeContext.euiTheme.colors[borderToken];
    return _objectSpread(_objectSpread({}, acc), {}, (0, _defineProperty2.default)({}, color, /*#__PURE__*/(0, _react.css)("border-color:", borderColor, ";label:", color, ";")));
  }, {});
};

/**
 * Hook to retrieve border style for a border variant
 * @returns An object map of color keys to CSS,
 * e.g. { danger: css``, success: css``, ... }
 */
var useEuiBorderColorCSS = exports.useEuiBorderColorCSS = function useEuiBorderColorCSS() {
  return (0, _services.useEuiMemoizedStyles)(_euiBorderColors);
};