"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "euiShadow", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiShadow;
  }
});
Object.defineProperty(exports, "euiShadowFlat", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiShadowFlat;
  }
});
Object.defineProperty(exports, "euiShadowLarge", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiShadowLarge;
  }
});
Object.defineProperty(exports, "euiShadowMedium", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiShadowMedium;
  }
});
Object.defineProperty(exports, "euiShadowSmall", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiShadowSmall;
  }
});
Object.defineProperty(exports, "euiShadowXLarge", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiShadowXLarge;
  }
});
Object.defineProperty(exports, "euiShadowXSmall", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiShadowXSmall;
  }
});
Object.defineProperty(exports, "euiSlightShadowHover", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiSlightShadowHover;
  }
});
exports.useEuiSlightShadowHover = exports.useEuiShadowFlat = exports.useEuiShadow = void 0;
var _euiThemeCommon = require("@elastic/eui-theme-common");
var _theme = require("../../services/theme");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var useEuiSlightShadowHover = exports.useEuiSlightShadowHover = function useEuiSlightShadowHover(options) {
  var euiThemeContext = (0, _theme.useEuiTheme)();
  return (0, _euiThemeCommon.euiSlightShadowHover)(euiThemeContext, options);
};
var useEuiShadowFlat = exports.useEuiShadowFlat = function useEuiShadowFlat(options) {
  var euiThemeContext = (0, _theme.useEuiTheme)();
  return (0, _euiThemeCommon.euiShadowFlat)(euiThemeContext, options);
};
var useEuiShadow = exports.useEuiShadow = function useEuiShadow() {
  var size = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'l';
  var options = arguments.length > 1 ? arguments[1] : undefined;
  var euiThemeContext = (0, _theme.useEuiTheme)();
  return (0, _euiThemeCommon.euiShadow)(euiThemeContext, size, options);
};