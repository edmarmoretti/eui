"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiThemeAnimationEasings", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.EuiThemeAnimationEasings;
  }
});
Object.defineProperty(exports, "EuiThemeAnimationSpeeds", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.EuiThemeAnimationSpeeds;
  }
});
Object.defineProperty(exports, "euiCanAnimate", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiCanAnimate;
  }
});
Object.defineProperty(exports, "euiCantAnimate", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.euiCantAnimate;
  }
});
var _euiThemeCommon = require("@elastic/eui-theme-common");