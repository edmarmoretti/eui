"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiThemeBreakpoints", {
  enumerable: true,
  get: function get() {
    return _euiThemeCommon.EuiThemeBreakpoints;
  }
});
var _euiThemeCommon = require("@elastic/eui-theme-common");